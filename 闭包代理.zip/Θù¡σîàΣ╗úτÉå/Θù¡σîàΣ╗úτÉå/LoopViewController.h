//
//  LoopViewController.h
//  闭包代理
//
//  Created by hipiao on 2017/2/20.
//  Copyright © 2017年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoopViewController : UIViewController

@end
