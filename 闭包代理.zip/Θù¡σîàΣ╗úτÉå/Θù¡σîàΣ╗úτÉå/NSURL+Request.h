//
//  NSURL+Request.h
//  闭包代理
//
//  Created by James Bond on 2017/2/19.
//  Copyright © 2017年 James. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (Request)

+(instancetype)request_urlWithString:(NSString *)urlString;


@end
