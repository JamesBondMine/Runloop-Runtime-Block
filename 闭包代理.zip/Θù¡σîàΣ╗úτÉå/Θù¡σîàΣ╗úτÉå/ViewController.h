//
//  ViewController.h
//  闭包代理
//
//  Created by hipiao on 2017/2/17.
//  Copyright © 2017年 James. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

