//
//  UIView+CustomView.m
//  闭包代理
//
//  Created by James Bond on 2017/2/19.
//  Copyright © 2017年 James. All rights reserved.
//

#import "UIView+CustomView.h"

@implementation UIView (CustomView)

@end
